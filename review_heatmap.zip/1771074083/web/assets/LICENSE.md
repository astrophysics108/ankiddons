## Credits and Licensing Terms for Icons

The following icons were either based off of public domain works or designed from scratch:

- circle.svg
- down.svg
- left.svg
- right.svg
- options.svg
- rate.svg

They are Copyright (c) 2018-2022 Glutanimate.

**License**

Licensed under the same variation of GNU Affero General Public License as the source code of this program (see LICENSE file).
